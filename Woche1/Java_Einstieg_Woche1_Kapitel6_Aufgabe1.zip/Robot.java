class Robot {
	void sayHello() {
		System.out.println("Hallo.");
	}

	void sayWelcome() {
		System.out.println("Willkommen.");
	}
}