class Robot {

int age = 5;

int getAge(){
    return age;
    }
}