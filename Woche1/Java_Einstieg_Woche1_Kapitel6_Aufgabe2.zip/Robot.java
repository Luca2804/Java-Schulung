class Robot {
    void giveTask() {
        System.out.println("Ich infiltriere die Geheimbasis und suche Paco.");
    }
}