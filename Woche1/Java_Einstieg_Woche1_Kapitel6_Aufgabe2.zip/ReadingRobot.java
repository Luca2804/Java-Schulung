class ReadingRobot{
    void giveTask() {
    
    System.out.println("Ich kann lesen.");
    
    }
}