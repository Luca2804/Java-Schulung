class Story {
    public static void main(String[] args) {
		Robot robin = new Robot();
		ReadingRobot alex = new ReadingRobot();          
		System.out.println(robin.getTask());
		System.out.println(alex.getTask());
    }
}