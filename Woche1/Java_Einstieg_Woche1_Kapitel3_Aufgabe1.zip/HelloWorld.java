class HelloWorld {
    public static void main(String[] args) {
        // Erstelle eine String Variable mit dem Bezeichner greeting und dem Wert "Willkommen Duke."
        String greeting = "Willkommen Duke.";
        
        // Gib anschliessend den Inhalt der Variable greeting aus

       System.out.println(greeting);
    }
}
