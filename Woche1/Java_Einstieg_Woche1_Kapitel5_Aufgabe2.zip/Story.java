class Story {
	public static void main(String[] args) {
	
	Robot robin = new Robot();
	
	robin.task = "Paco finden.";
	
	System.out.println(robin.task);
	}
}
