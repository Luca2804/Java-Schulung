class Robot {
    String task;
}