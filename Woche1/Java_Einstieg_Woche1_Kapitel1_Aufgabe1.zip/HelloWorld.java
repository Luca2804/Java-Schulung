class HelloWorld {
    public static void main(String[] args) {
        // Schreibe unter dieser Zeile: System.out.println("Der Anfang einer Reise!");
        System.out.println("Der Anfang einer Reise!");
        
    }
}
