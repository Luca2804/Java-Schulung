class Robot {
   void sayAge(){
       int age = 1;
       System.out.println("Ich bin " + age + " Jahr alt.");
   }
}
