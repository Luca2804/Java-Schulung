class HelloWorld {
    public static void main(String[] args) {
    	/* Ändere die drei einzelnen Kommentare zu einem mehrzeiligen Kommentar
         Schreibe anschließend ein Programm, das "Hallo, ich bin Duke." ausgibt
         und in einer neuen Zeile "Wie heißt Du?" ausgibt */
         System.out.println("Hallo, ich bin Duke.");
         System.out.println("Wie heißt Du?");

    }
}
