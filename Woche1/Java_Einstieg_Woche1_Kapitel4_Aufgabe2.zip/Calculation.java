class Calculation {
	public static void main(String[] args) {
    
    int a = 4;
    int b = 7;
    int c = 0;
    
    c = (a+b) * (a+b);
    
    System.out.println(c);
    
	}
}
