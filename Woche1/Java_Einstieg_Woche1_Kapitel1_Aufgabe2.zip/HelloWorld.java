class HelloWorld {
    // Hier haben sich zwei Fehler eingeschlichen
    public static void main (String[] args) {
        System.out.println("Hallo Welt.");
    }
}