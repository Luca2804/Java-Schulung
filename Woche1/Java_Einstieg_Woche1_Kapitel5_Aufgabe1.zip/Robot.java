class Robot {
    String name = "Kein Name";
}
