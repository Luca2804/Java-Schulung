class Robot {
    public static void main(String[] args) {
        // Ergaenze den richtigen Datentyp
       String name = "Robin";
       int age = 2;
       double runtime = 7.5;
        System.out.println(name + ", " + age + " Jahre alt, hat eine Laufzeit von " + runtime + "h.");
    }
}
