class Robot {
void testNumber(int Zahl){
    
    int Ergebnis = 0;
    
    Ergebnis = Zahl % 2;
    
    if(Ergebnis == 0){
        System.out.println("Die Zahl ist durch 2 teilbar!");
    }else{
        System.out.println("Die Zahl ist nicht durch 2 teilbar!");
    }
    
}

}
