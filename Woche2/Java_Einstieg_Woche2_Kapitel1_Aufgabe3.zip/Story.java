class Story {
	public static void main(String[] args) {
		
		GPS gps = new GPS();
		
		
		System.out.println(gps.getCoordinates("laenge"));
		System.out.println(gps.getCoordinates("hoehe"));
		System.out.println(gps.getCoordinates("breite"));
		
	}
}
