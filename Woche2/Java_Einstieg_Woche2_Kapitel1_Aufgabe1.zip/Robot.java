class Robot {

void speakTwice(String output){
    
    System.out.println(output);
    System.out.println(output);
    
    }
}
