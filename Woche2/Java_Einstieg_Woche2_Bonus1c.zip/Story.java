public class Story {
	
	int zero = 0;
	
	public static void main(String[] args){
		// füge hier deinen Programmcode ein
		for(int i = 1; i < 51 ; i++){
		    if(0 == i % 3 && 0 == i % 7){
		        System.out.println("ding-dong");
		    } else if (0 == i % 3){
		        System.out.println("ding");
		    } else if (0 == i % 7){
		        System.out.println("dong");
		    } else {
		        System.out.println("ping");
		    }
		}
	}

}