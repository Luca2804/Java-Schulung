class Robot {

String completeName(String Robin, String Suchroboter){
    String back;
    back = Robin + " " + Suchroboter;
    return back;
}

}
