class Robot {

    void countTo(int number){
        for(int i = 1; i < 21; i++){
            System.out.println(i);
        }
    }


}