class Robot {
    String sentence = "Ich kann sprechen!";
    RandomNumber rand = new RandomNumber();

void speakSeveralTimes(int par){
    for(int i = 0; i < par; i++){
        System.out.println(sentence);
    }
}

void speak(){
    
    speakSeveralTimes(rand.giveNumber());
}

}
