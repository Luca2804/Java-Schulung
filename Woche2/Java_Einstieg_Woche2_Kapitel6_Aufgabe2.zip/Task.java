class Task {
    String position;

Task(String position){
    this.position = position;
}

}
