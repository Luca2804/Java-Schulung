class Email {
    static String[][] ipaddress = HiddenIPAddress.getIPAddress();
}