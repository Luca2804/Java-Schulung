class Robot {

	int batteryRuntime = 5;
	boolean battery;

	boolean isBatteryRuntimeLow() {
		if (batteryRuntime < 2) {
		    // Ergänze in der nachfolgenden Zeile einen Rückgabewert
		    battery = true;
		    return battery;
            
		} else {
		    //Ergänze in der nachfolgenden Zeile einen Rückgabewert
            battery = false;
            return battery;
    	}
    }
}
