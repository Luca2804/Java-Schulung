public class Parrot implements Flyable {
    
    public void fly(){
        System.out.println("Ich fliege mit meinen Flügeln!");
    }

}
