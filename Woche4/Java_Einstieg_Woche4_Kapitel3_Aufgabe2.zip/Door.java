import java.util.HashMap;

class Door {

	HashMap<String, AccessCode> doorCodes = new HashMap<>();

    public void addDoorKey(String key, AccessCode obj){
        doorCodes.put(key, obj);
    }
	
    public void useCode(String key){
       if(doorCodes.get(key).getNumberOfTimesUsed() < 2){
           doorCodes.get(key).setNumberOfTimesUsed(doorCodes.get(key).getNumberOfTimesUsed() + 1);
           System.out.println("Schlüssel gültig");
       }else{
           doorCodes.get(key).setValid(false);
           System.out.println("Schlüssel nicht mehr gültig");
       }
    }
    	public HashMap<String, AccessCode> getDoorCodes() {
		return doorCodes;
	}
	
}
