import java.util.ArrayList;
import java.util.HashMap;

class Robot {
    
	private ArrayList<AccessCode> usedAccessCodes = new ArrayList<>();
	private ArrayList<AccessCode> unusedAccessCodes = new ArrayList<>();
	private HashMap<String, ArrayList<AccessCode>> codeHashMap = new HashMap<>();
	
	public void saveCodes(ArrayList<AccessCode> liste){
	    for(int i = 0; i < liste.size(); i++){
	        AccessCode ac = liste.get(i);
	        if(ac.getUsed()){
	            usedAccessCodes.add(ac);
	        }else{
	            unusedAccessCodes.add(ac);
	        }
	    }
	}
	
	public void buildHashMap(){
	    codeHashMap.put("used", usedAccessCodes);
	    codeHashMap.put("unused", unusedAccessCodes);
	}

}
