import java.util.ArrayList;

public class Robot {

    public void giveAccessCodes(ArrayList<String> list){
        for(String s : list){
            System.out.println(s);
        }
    }

}
