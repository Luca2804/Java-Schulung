public class Robot {

	private String name;
	private int age;
	private double batteryRuntime;

	Robot(String name, int age, double batteryRuntime) {
		this.name = name;
		this.age = age;
		this.batteryRuntime = batteryRuntime;
	}
	
	public Boolean equals(Robot o){
	    if (name == o.name && age == o.age && batteryRuntime == o.batteryRuntime){
	        return true;
	    }else{
	        return false;
	    }
	}
	
}
