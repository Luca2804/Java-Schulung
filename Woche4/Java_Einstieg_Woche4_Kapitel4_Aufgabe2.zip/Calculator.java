public class Calculator {

	int calculateSum(int[] numbers) {
		// Berechne hier die Summe aller Zahlen mit einer foreach Schleife und gib sie zurück:
		int summe = 0;
		for(int i : numbers){
		       summe += i;
		}
		return summe;
	}

	double calculateMean(int[] numbers) {
		double sum = calculateSum(numbers);
		// Berechne hier das Arithmetische Mittel und gib es zurück:
        return(sum / numbers.length);
	}
}
