import java.util.LinkedList;

public class TheChase {

LinkedList<Flyable> chasers = new LinkedList<>();

    public void addFlyable(Flyable chaser){
        chasers.add(chaser);
    }

    public void chase(){
       for(Flyable chaser : chasers){
        chaser.fly();
        }
    }

}
