interface Catchable {

    public abstract void tryToCatch(boolean bool);
}
