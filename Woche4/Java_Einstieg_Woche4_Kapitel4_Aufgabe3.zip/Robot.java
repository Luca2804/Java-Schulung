public class Robot {
	private String name;
	private String[] accessCodes = new String[]{"Mein ", "Zugangscode ", "ist ", "mein ", "Name: "};

	public Robot(String name) {
	this.name = name;
	}


	public String getAccessCode() {
		// Füge hier dein Code ein
		String code = "";
		for(String i : accessCodes){
		    code += i;
		}
		return(code + name);
	}
}
