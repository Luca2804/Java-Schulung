import java.util.ArrayList;

class Robot {
    
    ArrayList<AccessCode> accessCodes = new ArrayList<>();

	public Robot() {
		AccessCode firstCode = new AccessCode();
		firstCode.setCode("Federvieh");
		accessCodes.add(firstCode);
		AccessCode secondCode = new AccessCode();
		secondCode.setCode("e.vil");
		accessCodes.add(secondCode);
		AccessCode thirdCode = new AccessCode();
		thirdCode.setCode("2A2A");
		accessCodes.add(thirdCode);
	}

	public String getAccessCode(int i) {
        return accessCodes.get(i).getCode();
    }
    
    public ArrayList<AccessCode> getAccessCodes() {
        return accessCodes;
    }

}
