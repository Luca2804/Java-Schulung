public class Story {
	public static void main(String args[]) {
		MathRobot ronja = new MathRobot();
		System.out.println("3 durch 2 ist: " + ronja.div("3","2"));
		System.out.println("2 durch 2 ist: " + ronja.div("2","2"));
	}
}
