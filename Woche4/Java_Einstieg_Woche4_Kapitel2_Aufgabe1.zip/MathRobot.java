public class MathRobot {
	public double div(int a, int b) {
	    double x = 0.0;
	    
	    x = (double)a / (double)b;
	    
	    return x;
	    
		// Füge hier deinen Code ein
	}
}
