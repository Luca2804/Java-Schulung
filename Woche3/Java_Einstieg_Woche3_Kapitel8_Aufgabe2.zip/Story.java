class Story {
	
	public static void main(String[] args) {
		ReadingRobot bookworm = new ReadingRobot();
		System.out.println(bookworm.getBatteryRuntime());
	}
}
