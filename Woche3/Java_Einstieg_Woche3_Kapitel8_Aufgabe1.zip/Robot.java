class Robot {

	String task;

	Robot(String task) {
		this.task = task;
	}
	
	Robot(){
	    this("Duke helfen");
	}

}
