class DetectiveRobot extends Robot {

    @Override 
    void saySomething(){
        System.out.println("Ich suche Paco");
    }


}