class ReadingRobot extends Robot {

    @Override 
    void saySomething(){
        System.out.println("Ich lese Nachrichten");
    }

}