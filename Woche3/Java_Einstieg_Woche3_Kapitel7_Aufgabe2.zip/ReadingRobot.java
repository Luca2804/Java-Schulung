class ReadingRobot extends Robot{

    ReadingRobot() {
        batteryRuntime = 5;
    }

}
