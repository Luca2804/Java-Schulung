abstract class AbstractOpener {
	String type;

	abstract public boolean open(String type);
}
