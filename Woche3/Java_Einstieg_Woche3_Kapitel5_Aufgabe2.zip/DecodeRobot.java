class DecodeRobot {

void tap(String wort, int Zahl){
    for(int i = 0; i < Zahl; i++){
        System.out.println(wort);
    }
}

void tap(String wort){
    tap(wort,3);
}

}
