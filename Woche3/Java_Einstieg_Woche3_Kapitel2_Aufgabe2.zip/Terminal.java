class Terminal {

public void hackRobot(TestRobot tr){
    System.out.println(tr.numberOfProcessorCores);
    System.out.println(tr.hasFirewall);
    System.out.println(tr.id);
}

}
