class DetectiveRobot extends Robot {

	DetectiveRobot() {
	    this.batteryRuntime = 5;
	    this.canSpeak = true;

	}

	void speak() {
	    if (canSpeak) {
		    System.out.println("Ich heiße Ronja und meine Batterie hält " + batteryRuntime + " Stunden.");
	    }
    }
}
