class DetectiveRobot extends Robot {
    int spareBatteryRuntime = 5;
    int totalBatteryRuntime = 0;
    
    int giveTotalBatteryRuntime(){
        totalBatteryRuntime = giveBatteryRuntime() + spareBatteryRuntime;
        return totalBatteryRuntime;
    }

}
