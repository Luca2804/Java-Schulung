class Robot {
	int batteryRuntime = 10;

	int giveBatteryRuntime() {
		return batteryRuntime;
	}
}
