class Animal {

	void move() {
		System.out.println("Ich bewege mich");
	}
}