class Parrot extends Animal {

	void speak() {
		System.out.println("Ich kann sprechen");
	}
	
	void speak(String Satz){
	    System.out.println(Satz);
	}
    
    @Override 
    	void move() {
		System.out.println("Ich fliege");
	}
    
}