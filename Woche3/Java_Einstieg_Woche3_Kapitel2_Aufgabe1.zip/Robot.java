public class Robot {
	private int secretKey = 602413;
	int numberOfProcessorCores = 4;
	protected boolean hasFirewall = false;
	public String id = "58-08-2";
}
