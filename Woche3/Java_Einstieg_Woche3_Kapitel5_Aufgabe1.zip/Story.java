class Story {

	public static void main(String[] args) {
		MathRobot mathRobot = new MathRobot();
		System.out.println(mathRobot.addition(2, 3));
		System.out.println(mathRobot.addition(2, 3, 5));
		System.out.println(mathRobot.addition(2.0, 3.2));
		System.out.println(mathRobot.addition(2.0, 3.2, 0.6));
	}

}
