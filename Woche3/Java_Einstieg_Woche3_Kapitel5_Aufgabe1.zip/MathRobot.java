public class MathRobot {

int addition(int i, int j){
   return i + j; 
}

int addition(int i, int j, int k){
    return i+j+k;
}

double addition(double i, double j){
    return i+j;
}

double addition(double i, double j, double k){
    return i+j+k;
}

}
